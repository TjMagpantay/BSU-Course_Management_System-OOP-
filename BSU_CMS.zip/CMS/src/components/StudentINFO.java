package components;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.*;

public class StudentINFO {
    private final String filePath;

    public StudentINFO(String filePath) {
        this.filePath = filePath;
    }

    public void setData(String fullName, String course) {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("fullName", fullName);
        jsonObject.addProperty("course", course);

        writeJsonToFile(jsonObject);
    }

    public String[] getStudentInfo() {
        JsonObject jsonObject = readJsonFile();
        if (jsonObject != null) {
            String fullName = jsonObject.has("fullName") ? jsonObject.get("fullName").getAsString() : null;
            String course = jsonObject.has("course") ? jsonObject.get("course").getAsString() : null;
            return new String[]{fullName, course};
        }
        return null;
    }

    private void writeJsonToFile(JsonObject jsonObject) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(jsonObject.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private JsonObject readJsonFile() {
        try (FileReader reader = new FileReader(filePath)) {
            return new Gson().fromJson(reader, JsonObject.class);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
